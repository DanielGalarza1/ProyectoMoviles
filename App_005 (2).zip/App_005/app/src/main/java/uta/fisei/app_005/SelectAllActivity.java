package uta.fisei.app_005;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SelectAllActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_all);
    }
}