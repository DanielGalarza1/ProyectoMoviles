package uta.fisei.app_005;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ShowAllActivity extends AppCompatActivity {

    private ListView listViewDataClients;
    private ArrayAdapter adapter;
    private ArrayList<String> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all);

        listViewDataClients = findViewById(R.id.listViewDataClients);

        list = getData();

        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);

        listViewDataClients.setAdapter(adapter);
    }

    private ArrayList<String> getData() {
        DataBaseManager dataBaseManager = new DataBaseManager(this, "SEXTO_DB",null, 1);
        SQLiteDatabase sqLiteDatabase = dataBaseManager.getWritableDatabase();

        String select = "SELECT Code, Name, LastName, Phone, Balance FROM Clients";

        Cursor cursor = sqLiteDatabase.rawQuery(select, null);

        ArrayList<String> listData = new ArrayList<>();

        if (cursor.moveToFirst()){
            while (cursor.moveToNext()){
                listData.add(cursor.getString(1));
            }
        }else {
            Toast.makeText(this,"No Existen Datos",
                    Toast.LENGTH_SHORT).show();
        }
        sqLiteDatabase.close();
        return  listData;
    }
}