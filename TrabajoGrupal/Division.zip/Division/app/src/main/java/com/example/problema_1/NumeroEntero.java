package com.example.problema_1;

import java.math.BigDecimal;

import java.math.BigDecimal;

public class NumeroEntero {
    private BigDecimal valor;
    private StringBuilder procedimiento;

    public NumeroEntero(String numero) {
        this.valor = new BigDecimal(numero);
        this.procedimiento = new StringBuilder();
    }

    public StringBuilder dividir(NumeroEntero otroNumero) {
        if (otroNumero.esCero()) {
            throw new ArithmeticException("No se puede dividir por cero.");
        }

        BigDecimal divisor = otroNumero.getValor();
        BigDecimal cociente = this.valor.divide(divisor, 15, BigDecimal.ROUND_DOWN);
        BigDecimal residuo = this.valor.remainder(divisor);

        if (residuo.compareTo(BigDecimal.ZERO) == 0) {
            procedimiento.append("Resultado: ").append(cociente.intValue()); // Mostrar solo el entero
        } else {
            procedimiento.append("Resultado: ").append(cociente);

            if (residuo.compareTo(BigDecimal.ZERO) != 0) {
                procedimiento.append("\nCon Residuo: ").append(residuo);
            }
        }
        return procedimiento;
    }

    public boolean esCero() {
        return this.valor.compareTo(BigDecimal.ZERO) == 0;
    }

    public BigDecimal getValor() {
        return this.valor;
    }
}

